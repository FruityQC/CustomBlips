fx_version 'bodacious'
game 'gta5'

author 'TheYoungDevelopper'
version '1.0.0'

client_script 'client.lua'